import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { Transaction, DBSCANConfig, DBSCANResult } from './types';
import { generateTransactions } from './data/mockDataGenerator';
import { runDBSCAN } from './algorithms/dbscan';
import { api, UserProfile, JobStatus } from './services/api';

import { Sidebar, NavTab } from './components/common/Sidebar';
import { Header } from './components/common/Header';
import { LoginView } from './components/auth/LoginView';
import { RegisterView } from './components/auth/RegisterView';
import { DatasetUploadView } from './components/upload/DatasetUploadView';
import { ProcessingProgressBar } from './components/common/ProcessingProgressBar';

import { DashboardView } from './components/dashboard/DashboardView';
import { EDAView } from './components/eda/EDAView';
import { CorrelationView } from './components/correlation/CorrelationView';
import { FeatureAnalysisView } from './components/features/FeatureAnalysisView';
import { DBSCANView } from './components/dbscan/DBSCANView';
import { AnomaliesView } from './components/anomalies/AnomaliesView';
import { PerformanceView } from './components/performance/PerformanceView';
import { ModelArchitectureView } from './components/model/ModelArchitectureView';
import { TransactionDetailModal } from './components/common/TransactionDetailModal';

export const App: React.FC = () => {
  // Theme state
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');

  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return !!localStorage.getItem('fraudguard_token');
  });
  const [authView, setAuthView] = useState<'login' | 'register'>('login');
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    return api.getCurrentUser() || {
      username: 'admin',
      full_name: 'System Administrator',
      email: 'admin@fraudguard.internal'
    };
  });

  // Navigation tab
  const [currentTab, setCurrentTab] = useState<NavTab>('overview');

  // Dataset info
  const [datasetName, setDatasetName] = useState<string>('fraud_transaction_dataset.csv (Demo)');
  const [isDemo, setIsDemo] = useState<boolean>(true);

  // Background Job & Processing State
  const [activeJob, setActiveJob] = useState<JobStatus | null>(null);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // Inspected transaction
  const [inspectedTx, setInspectedTx] = useState<Transaction | null>(null);

  // DBSCAN Configuration
  const [config, setConfig] = useState<DBSCANConfig>({
    eps: 2.9,
    min_samples: 5,
    selectedFeatures: [
      'amount',
      'frequency_24h',
      'location_distance',
      'amount_deviation',
      'merchant_risk'
    ]
  });

  // Base raw transactions
  const [rawTransactions, setRawTransactions] = useState<Transaction[]>(() => {
    return generateTransactions(2500, 42);
  });

  // Apply theme attribute
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  // Execute DBSCAN clustering
  const { transactions, result: dbscanResult } = useMemo(() => {
    // Backend labels are canonical results from the notebook-matched pipeline.
    if (rawTransactions.length > 0 && rawTransactions.every(t => typeof t.cluster === 'number')) {
      const labels = rawTransactions.map(t => Number(t.cluster));
      const clusterSizes: Record<number, number> = {};
      let numNoise = 0;
      labels.forEach(label => {
        if (label === -1) numNoise++;
        else clusterSizes[label] = (clusterSizes[label] || 0) + 1;
      });
      return {
        transactions: rawTransactions,
        result: {
          clusters: labels,
          numClusters: Object.keys(clusterSizes).length,
          numNoise,
          noiseRatio: rawTransactions.length ? numNoise / rawTransactions.length : 0,
          clusterSizes
        }
      };
    }
    return runDBSCAN(rawTransactions, config);
  }, [rawTransactions, config]);

  // Auth Handlers
  const handleLoginSuccess = (authData: any) => {
    setIsAuthenticated(true);
    setCurrentUser(authData.user);
    setCurrentTab('overview');
  };

  const handleLogout = () => {
    api.logout();
    setIsAuthenticated(false);
    setAuthView('login');
  };

  // Toggle Theme
  const toggleTheme = () => {
    setTheme(prev => (prev === 'dark' ? 'light' : 'dark'));
  };

  // Trigger background job when re-clustering via backend or sliders
  const handleUpdateConfig = useCallback(async (newConfig: DBSCANConfig) => {
    setConfig(newConfig);
    try {
      setIsProcessing(true);
      const jobId = await api.startDBSCANJob(newConfig.eps, newConfig.min_samples);
      
      // Poll job progress
      const pollInterval = setInterval(async () => {
        try {
          const status = await api.pollJobStatus(jobId);
          setActiveJob(status);
          if (status.status === 'completed' || status.status === 'failed') {
            clearInterval(pollInterval);
            setIsProcessing(false);
            if (status.status === 'completed') {
              // Pull the newly computed backend labels; never leave stale predictions visible.
              api.getAnalyticsPayload()
                .then((payload: any) => handleDatasetLoaded(payload))
                .catch((error: any) => console.error('Could not refresh DBSCAN predictions:', error));
            }
            setTimeout(() => setActiveJob(null), 800);
          }
        } catch {
          clearInterval(pollInterval);
          setIsProcessing(false);
          setActiveJob(null);
        }
      }, 250);
    } catch {
      // If backend is not reached, client-side useMemo handles it instantly
      setIsProcessing(false);
    }
  }, []);

  // Load canonical rows from the backend after dataset upload/demo load.
  const handleDatasetLoaded = async (data: any) => {
    setDatasetName(data.filename || data.dataset_name || 'uploaded_dataset.csv');
    setIsDemo(!!data.is_demo);
    try {
      const response = await api.getTransactions(1, 10000, 'all', '');
      const rows = response.rows || [];
      if (rows.length) {
        const converted: Transaction[] = rows.map((p: any) => ({
          id: String(p.id), timestamp: p.timestamp || '',
          hour: Number(p.hour ?? 12), amount: Number(p.amount ?? 0),
          frequency_24h: Number(p.frequency_24h ?? 0),
          location_distance: Number(p.location_distance ?? 0),
          device_change: (String(p.device_change) === '1' || String(p.device_change).toLowerCase() === 'changed device') ? 'Changed Device' : 'Known Device',
          login_attempts: Number(p.login_attempts ?? 0),
          account_age: Number(p.account_age_days ?? 365),
          prev_tx_avg: Number(p.prev_tx_avg ?? 0),
          amount_deviation: Number(p.amount_deviation ?? 0),
          merchant_risk: Number(p.merchant_risk ?? 0),
          tx_duration: Number(p.transaction_duration_sec ?? 45),
          account_balance: Number(p.account_balance ?? 0),
          amount_to_balance: Number(p.amount_to_balance_ratio ?? 0),
          channel: String(p.channel ?? 'Mobile'),
          fraud_label: Number(p.fraud_label ?? 0),
          project_risk_score: Number(p.project_risk_score ?? 0),
          risk_category: p.is_anomaly ? 'Potential Anomaly' : 'Low Risk',
          cluster: Number(p.cluster), is_anomaly: Boolean(p.is_anomaly)
        } as Transaction));
        setRawTransactions(converted);
        return;
      }
    } catch (error) {
      console.error('Could not load canonical processed transactions:', error);
    }
    // Avoid silently substituting randomly generated transactions.
    setRawTransactions([]);
  };

  // Initialize the visible frontend from the backend's active dataset and its
  // canonical predictions instead of the randomly generated browser sample.
  useEffect(() => {
    api.getAnalyticsPayload()
      .then((data: any) => handleDatasetLoaded(data))
      .catch((error: any) => {
        console.error('Backend dataset is unavailable. Start the backend first.', error);
        setRawTransactions([]);
      });
  }, []);

  // 1-Click Load Demo Dataset
  const handleLoadDemoDataset = async () => {
    try {
      setIsProcessing(true);
      const res = await api.loadDemoDataset();
      handleDatasetLoaded(res);
      setDatasetName('fraud_transaction_dataset.csv (Demo)');
      setIsDemo(true);
    } catch (error) {
      console.error('Could not load demo dataset from backend:', error);
      setRawTransactions([]);
      setDatasetName('Dataset unavailable — start the backend');
      setIsDemo(true);
    } finally {
      setIsProcessing(false);
    }
  };

  // CSV Export
  const handleExportCSV = () => {
    if (transactions.length === 0) return;
    const headers = [
      'Transaction_ID',
      'Timestamp',
      'Transaction_Hour',
      'Transaction_Amount',
      'Transaction_Frequency_24H',
      'Location_Distance_KM',
      'Device_Change',
      'Login_Attempts',
      'Amount_Deviation',
      'Merchant_Risk_Score',
      'Channel',
      'Cluster',
      'Is_Anomaly',
      'Fraud_Label',
      'Project_Risk_Score'
    ];
    const rows = transactions.map(t =>
      [
        t.id,
        t.timestamp,
        t.hour,
        t.amount,
        t.frequency_24h,
        t.location_distance,
        t.device_change,
        t.login_attempts,
        t.amount_deviation,
        t.merchant_risk,
        t.channel,
        t.cluster,
        t.is_anomaly ? 1 : 0,
        t.fraud_label,
        t.project_risk_score
      ].join(',')
    );

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `fraudguard_transactions_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Page titles mapping
  const pageTitles: Record<NavTab, string> = {
    overview: 'Executive Surveillance Dashboard',
    dataset: 'Transaction Dataset Management & Ingestion',
    eda: 'Exploratory Data Analytics (EDA)',
    correlation: 'Pairwise Correlation Matrix Analysis',
    features: 'Unsupervised Feature Distribution Deep-Dive',
    dbscan: 'DBSCAN Hyperparameter Tuning & 2D Projection',
    anomalies: 'Anomaly Radar & Threat Investigation',
    performance: 'Algorithmic Benchmark Evaluation',
    model: 'DBSCAN Architecture & Theoretical Guide'
  };

  // Unauthenticated Flow
  if (!isAuthenticated) {
    if (authView === 'login') {
      return (
        <LoginView
          onLoginSuccess={handleLoginSuccess}
          onNavigateToRegister={() => setAuthView('register')}
        />
      );
    }
    return (
      <RegisterView
        onRegisterSuccess={() => setAuthView('login')}
        onNavigateToLogin={() => setAuthView('login')}
      />
    );
  }

  // Authenticated FraudGuard Terminal Flow
  return (
    <div className="fraudguard-layout">
      {/* Redesigned Dark Navy Sidebar */}
      <Sidebar
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        onLoadDemo={handleLoadDemoDataset}
        onLogout={handleLogout}
        datasetName={datasetName}
        isDemo={isDemo}
      />

      {/* Main Workspace Area */}
      <div className="fraudguard-main-area">
        <Header
          pageTitle={pageTitles[currentTab]}
          datasetName={datasetName}
          isDemo={isDemo}
          statusText={isProcessing ? 'Processing Pipeline...' : 'Analysis Ready'}
          user={currentUser}
          theme={theme}
          onToggleTheme={toggleTheme}
          onExportCSV={handleExportCSV}
          onRefreshAnalytics={() => handleUpdateConfig(config)}
          isProcessing={isProcessing}
        />

        <main className="main-content">
          {currentTab === 'overview' && (
            <DashboardView
              transactions={transactions}
              dbscanResult={dbscanResult}
              onNavigateToAnomalies={() => setCurrentTab('anomalies')}
              onInspectTransaction={setInspectedTx}
            />
          )}

          {currentTab === 'dataset' && (
            <DatasetUploadView
              onDatasetLoaded={handleDatasetLoaded}
              onProceedToEDA={() => setCurrentTab('eda')}
            />
          )}

          {currentTab === 'eda' && <EDAView transactions={transactions} />}

          {currentTab === 'correlation' && <CorrelationView transactions={transactions} />}

          {currentTab === 'features' && <FeatureAnalysisView transactions={transactions} />}

          {currentTab === 'dbscan' && (
            <DBSCANView
              transactions={transactions}
              config={config}
              onUpdateConfig={handleUpdateConfig}
              dbscanResult={dbscanResult}
              onInspectTransaction={setInspectedTx}
            />
          )}

          {currentTab === 'anomalies' && (
            <AnomaliesView
              transactions={transactions}
              onInspectTransaction={setInspectedTx}
            />
          )}

          {currentTab === 'performance' && (
            <PerformanceView
              transactions={transactions}
              onApplyEps={eps => handleUpdateConfig({ ...config, eps })}
            />
          )}

          {currentTab === 'model' && <ModelArchitectureView />}
        </main>
      </div>

      {/* Asynchronous ML Progress Checklist */}
      <ProcessingProgressBar jobStatus={activeJob} />

      {/* Transaction Forensic Dossier Modal */}
      <TransactionDetailModal
        transaction={inspectedTx}
        onClose={() => setInspectedTx(null)}
      />
    </div>
  );
};

export default App;
