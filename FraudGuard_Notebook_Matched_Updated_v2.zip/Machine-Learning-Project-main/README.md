# FraudGuard — DBSCAN Fraud/Anomaly Detection

This project uses the bundled `backend/data/fraud_transaction_dataset_1000_fixed.csv` by default, so the dashboard starts with the supplied 1,000-row dataset rather than generated demo data.

## Model behavior

- The backend follows the preprocessing sequence in `Fraud_Transaction_DBSCAN_Final_Organized.ipynb`: exclude `Fraud_Label` and identifiers from model input, engineer cyclical hour features, apply the notebook's `log1p` transforms, one-hot encode `Location`, `Transaction_Type`, and `Channel`, and apply `RobustScaler`.
- Default DBSCAN parameters are `eps=2.9` and `min_samples=5`, matching the notebook.
- `Fraud_Label` is used only for evaluation, not as a model feature.
- The frontend displays backend-computed cluster labels and does not re-cluster a partial sample with a different browser-side algorithm.
- With the supplied CSV and these settings, the reference notebook result is **104 candidate anomalies**, **99.60% accuracy**, **96.15% precision**, **100.00% recall**, and **98.04% F1**. These values describe this dataset and are not a guarantee of real-world fraud performance.

## Start on Windows

### 1. Backend (PowerShell, terminal 1)

From the project folder:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
python -m pip install fastapi uvicorn pandas numpy scikit-learn python-multipart
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```

Keep this terminal running. The API health endpoint is `http://127.0.0.1:8000/api/health`.

### 2. Frontend (PowerShell, terminal 2)

From the project root:

```powershell
npm install
npm run dev
```

Open the local URL printed by Vite (usually `http://localhost:5173`).

## Repeatability

The same CSV, preprocessing pipeline, and DBSCAN parameters produce the same labels on repeated runs. Changing the CSV or DBSCAN parameters can legitimately change the predictions and evaluation metrics. The frontend keeps the existing design; this update changes the data/model wiring and default dataset/model settings.


## Notebook-matched DBSCAN reference run

The backend's default pipeline mirrors `Fraud_Transaction_DBSCAN_Final (1).ipynb`:
- Excludes `Fraud_Label`, identifiers, and timestamp from model inputs.
- Engineers `Hour_Sin` and `Hour_Cos`, applies `log1p` to the notebook's six skewed numeric features, uses `RobustScaler` and one-hot encodes `Location`, `Transaction_Type`, and `Channel`.
- Runs DBSCAN with `eps=2.9` and `min_samples=5`.
- The bundled `backend/data/fraud_transaction_dataset_1000_fixed.csv` is the reference 1,000-row dataset.

Expected reference result for this exact dataset and pipeline: **896 clustered/normal transactions and 104 DBSCAN noise/anomaly candidates**. Against `Fraud_Label`, the notebook-matched confusion counts are TN=896, FP=4, TP=100, FN=0 (accuracy 99.60%, precision 96.15%, recall 100%, F1 98.04%). DBSCAN noise indicates candidate anomalies, not confirmed fraud.

Start backend from the project root:
```powershell
cd backend
python -m pip install -r requirements.txt
python -m uvicorn main:app --reload --host 127.0.0.1 --port 8000
```
In a second terminal, from the project root:
```powershell
npm install
npm run dev
```
